#!/usr/bin/env python
# -*- coding: utf-8 -*-

import apt
import apt_pkg
from PyQt4 import QtGui, QtCore
import os, sys
from stat import *
import zipfile
import shutil
import apt.debfile
from zipfile import ZipFile as zip

from PyQt4.QtGui import QSplashScreen, QPixmap
from PyQt4.QtCore import Qt

import subprocess, gobject, tempfile
import gksu2 as gksu

class Dialog(QtGui.QMainWindow):
    def __init__(self):

        splash_dir = '/usr/share/dac-manager/splash.png'
        if not os.path.exists(splash_dir):
            splash_dir = './splash.png'
        splash_pix = QPixmap(splash_dir)
        splash = QSplashScreen(splash_pix, Qt.WindowStaysOnTopHint)
        splash.show()
        splash.showMessage("Loading GUI...", Qt.AlignRight | Qt.AlignTop, Qt.black)

        super(Dialog, self).__init__()

        self.initUI()
        
        savedCursor = self.cursor()
        self.setCursor(Qt.BusyCursor)

        #Messages
        self.MESSAGE1 = "<p>You must select one or more packages.</p>"
        self.MESSAGE2 = "<p>The program isn't work correctly because you haven't a rigth connection with one repository</p>"
        self.MESSAGE3 = "<p> You have not connection with a real repository.</p>"
        self.MESSAGE4 = "<p> The download was completed.</p>"
        self.MESSAGE5 = "<p> To run this function the program must be run like sudo users. </p>"
        self.MSG_PKG_NOT_FOUND = "<p> No se encontraron paquetes con ese nombre. </p>"
        self.MSG_ASK_PGK = "<p> Enter the name of the package to search: </p>"

        #Cache init
        self.cache =apt.Cache()
        self.cache.open(None)
        self.cache.upgrade(True)

        #Table
        self.header = ['Package', 'Version', 'Installed version', 'Description']
        self.vheader =['']
        self.ls = self.allPackages()
        self.rows =len(self.ls)
        self.table =QtGui.QTableWidget(self.rows, 4)
        self.table.setSelectionBehavior(self.table.SelectRows)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setHorizontalHeaderLabels(self.header)
        self.table.selectRow(0)
        self.table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)

        #Buttons
        self.dwBtn = QtGui.QPushButton('Make package', self)
        self.srBtn = QtGui.QPushButton('Search package', self)
        self.rfBtn = QtGui.QPushButton('Reload', self)
        self.inBtn = QtGui.QPushButton('Install', self)

        self.txt =QtGui.QTextEdit(self)
        self.txt.setReadOnly(True)

        #Actions
        helpAction = QtGui.QAction('&Description', self)
        helpAction.setShortcut('Ctrl+D')
        helpAction.triggered.connect(self.description)

        aboutAction = QtGui.QAction('&About us', self)
        aboutAction.setShortcut('Ctrl+A')
        aboutAction.triggered.connect(self.about)

        makeAction =QtGui.QAction('&Make package', self)
        makeAction.setShortcut('Ctrl+M')
        makeAction.triggered.connect(self.download)

        searchAction =QtGui.QAction('&Search', self)
        searchAction.setShortcut('Ctrl+S')
        searchAction.triggered.connect(self.search)

        exitAction = QtGui.QAction('&Exit', self)
        exitAction.setShortcut('Ctrl+X')
        exitAction.triggered.connect(self.salir)

        #Menu Bar
        self.mbar = self.menuBar()
        afile =self.mbar.addMenu('&File')
        ahelp =self.mbar.addMenu('&Help')

        afile.addAction(makeAction)
        afile.addAction(searchAction)
        afile.addAction(exitAction)
        ahelp.addAction(helpAction)
        ahelp.addAction(aboutAction)

        #Layouts
        self.mainWidget=QtGui.QWidget(self)
        self.setCentralWidget(self.mainWidget)
        self.mainLayout = QtGui.QVBoxLayout(self.mainWidget)
        self.tableLayout = QtGui.QVBoxLayout()
        self.tableLayout.addWidget(self.table)
        self.mainLayout.addLayout(self.tableLayout)

        self.buttonLayout = QtGui.QHBoxLayout()
        self.buttonLayout.addWidget(self.dwBtn)
        self.buttonLayout.addWidget(self.srBtn)
        self.buttonLayout.addWidget(self.rfBtn)
        self.buttonLayout.addWidget(self.inBtn)
        self.mainLayout.addLayout(self.buttonLayout)

        self.txtLayout = QtGui.QHBoxLayout()
        self.txtLayout.addWidget(self.txt)
        self.mainLayout.addLayout(self.txtLayout)

        #Progress Dialog
        self.pd = QtGui.QProgressDialog("Downloading files...", "Abort download", 0, 100)
        self.pd.setWindowModality(QtCore.Qt.WindowModal)
        self.pd.setWindowTitle('Downloading...')
        self.pd.setMaximumSize(500,100)
        self.pd.setMinimumSize(500,100)

        #Progress Dialog
        self.pdi =QtGui.QProgressDialog("Installing files...", "Abort install", 0, 100)
        self.pdi.setWindowModality(QtCore.Qt.WindowModal)
        self.pdi.setWindowTitle('Downloading...')
        self.pdi.setMaximumSize(500,100)
        self.pdi.setMinimumSize(500,100)

        #Connections
        QtCore.QObject.connect(self.table, QtCore.SIGNAL("cellPressed(int, int)"), self.package)
        QtCore.QObject.connect(self.table, QtCore.SIGNAL("cellClicked(int, int)"), self.myItem)
        QtCore.QObject.connect(self.table, QtCore.SIGNAL("cellDoubleClicked(int, int)"),self.check)
        QtCore.QObject.connect(self.rfBtn, QtCore.SIGNAL("clicked()"), self.data_table)
        QtCore.QObject.connect(self.srBtn, QtCore.SIGNAL("clicked()"), self.search)
        QtCore.QObject.connect(self.dwBtn, QtCore.SIGNAL("clicked()"), self.download)
        QtCore.QObject.connect(self.inBtn, QtCore.SIGNAL("clicked()"), self.install)
        self.table.customContextMenuRequested.connect(self.openMenu)

        self.sudo_password = None

        #Methods
        self.data_table()
        
        self.show()
        splash.finish(self)
        self.setCursor(savedCursor)

    def salir(self):
        sys.exit()

    def createTabD(self,fileInfo):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.setWindowTitle(fileInfo + ' properties')
        self.tabWidget.addTab(CommonsTab(fileInfo), "Commons")
        self.tabWidget.addTab(DependsTab(fileInfo), "Dependecies")
        self.tabWidget.addTab(VersionsTab(fileInfo), "Versions")
        self.tabWidget.addTab(DescriptionTab(fileInfo), "Descriptions")
        self.tabWidget.setGeometry(200,200,600,400)
        self.tabWidget.setMinimumSize(600,400)

    def fin(self):
        reply = QtGui.QMessageBox.information(self, "Information", self.MESSAGE4)
        if reply == QtGui.QMessageBox.Ok:
            self.show()

    def about(self):
        QtGui.QMessageBox.about(self, self.tr("About DacManager tool"),
            self.tr("Vanta DacManager\n\n"
                    "%s\n%s\n%s\n\n"
                    "  Copyright(C) %s v%s"
                    %("Ing.Alain Arias Yanez","MSc. Eugeny Yero Rodriguez","MSc. Eduardo Barea Bermudez","2012","1.0")))

    def description(self):
        QtGui.QMessageBox.about(self, self.tr("DacManager tool description"), self.tr("DacManager tools can be used to eliminate the higher repository dependencies of Debian based distribution allowing compress in only one package all the dependencies needed to install one application.\n\n DAC stand for Debian Auto Content, meaning that all packages needed for one application are be auto contained in our .dac package. "))


    def initUI(self):
        self.setGeometry(60,60,1000,600)
        self.setWindowTitle('Vanta DacManager Copyright(C) 2012 v1.0')
        #self.show()

    ##############SLOTS#####################

    def package(self,i,j):
        if not j == 0:
            name =str(self.table.item(i,0).text())
            pk =self.cache[name]
        else:
            name =str(self.table.item(i,j).text())
            pk =self.cache[name]
        self.fileInfo =pk.name
        self.i= i
        self.j= j


    def openMenu(self,i):

        menu =QtGui.QMenu(self)
        menu.setMaximumWidth(200)
        menu.setMinimumWidth(200)

        action2 = menu.addAction("Mark" + "/" + "Unmark")
        action3 = menu.addAction("Properties")
        action1 = menu.exec_(self.table.mapToGlobal(i))
        if action1 == action3:
            self.createTabD(self.fileInfo)
            self.tabWidget.show()
        elif action1 == action2:
            self.check(self.i, self.j)

    def myItem(self,i,j):
        if not j == 0:
            name =str(self.table.item(i,0).text())
            pk =self.cache[name]
            self.txt.setText(pk.description)
        else:
            name =str(self.table.item(i,j).text())
            pk =self.cache[name]
            self.txt.setText(pk.description)

    def check(self,i,j):
        if self.table.item(i,0).checkState() == 0:
            if not j == 0:
                self.table.item(i,0).setCheckState(QtCore.Qt.Checked)
            else:
                self.table.item(i,0).setCheckState(QtCore.Qt.Checked)
        else:
            self.table.item(i,0).setCheckState(QtCore.Qt.Unchecked)

    ##############SLOTS#####################

    def search(self):
        text, ok = QtGui.QInputDialog.getText(self, 'Package', self.MSG_ASK_PGK)
        if ok:
            savedCursor = self.cursor()
            self.setCursor(Qt.BusyCursor)
            op = self.find(str(text))
            if not op:
                QtGui.QMessageBox.information(self, "Information", self.MSG_PKG_NOT_FOUND)
            self.data_table(op)
            self.setCursor(savedCursor)

    def data_table(self, op =[]):
        savedCursor = self.cursor()
        self.setCursor(Qt.BusyCursor)
        self.a =[]
        if op == []:
            self.a =self.ls
            self.rows =len(self.a)
            self.table.setRowCount(self.rows)
            self.n =0
            self.table.setSortingEnabled(False)
            for item in self.a:
                self.newitem = QtGui.QTableWidgetItem(item.name)
                self.newitem.data(QtCore.Qt.CheckStateRole)
                self.newitem.setCheckState(QtCore.Qt.Unchecked)
                self.newitem.setFlags(QtCore.Qt.ItemIsEnabled)
                self.table.setItem(self.n, 0, self.newitem)

                if not (item.candidateVersion == None):
                    self.newitem2 = QtGui.QTableWidgetItem(item.candidateVersion)
                    self.newitem2.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 1, self.newitem2)
                else:
                    self.newitem2 = QtGui.QTableWidgetItem('')
                    self.newitem2.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 1, self.newitem2)

                if not item.summary == None:
                    self.newitem4 = QtGui.QTableWidgetItem(item.summary)
                    self.newitem4.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 3, self.newitem4)
                else:
                    self.newitem4 = QtGui.QTableWidgetItem('')
                    self.newitem4.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 3, self.newitem4)

                if not item.installedVersion == None:
                    self.newitem3 = QtGui.QTableWidgetItem(item.installedVersion)
                    self.newitem3.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 2, self.newitem3)
                    self.n +=1
                else:
                    self.newitem3 = QtGui.QTableWidgetItem('')
                    self.newitem3.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 2, self.newitem3)
                    self.n +=1
            self.table.setSortingEnabled(True)
        else:
            self.table.setSortingEnabled(False)
            self.a = op
            self.table.clearContents()
            self.rows =len(self.a)
            self.table.setRowCount(self.rows)
            self.n =0
            for item in self.a:
                self.newitem = QtGui.QTableWidgetItem(item.name)
                self.newitem.data(QtCore.Qt.CheckStateRole)
                self.newitem.setCheckState(QtCore.Qt.Unchecked)
                self.newitem.setFlags(QtCore.Qt.ItemIsEnabled)
                self.table.setItem(self.n, 0, self.newitem)
#~
                if not (item.candidateVersion == None):
                    self.newitem2 = QtGui.QTableWidgetItem(item.candidateVersion)
                    self.newitem2.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 1, self.newitem2)
                else:
                    self.newitem2 = QtGui.QTableWidgetItem('')
                    self.newitem2.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 1, self.newitem2)

                if not item.summary == None:
                    self.newitem4 = QtGui.QTableWidgetItem(item.summary)
                    self.newitem4.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 3, self.newitem4)
                else:
                    self.newitem4 = QtGui.QTableWidgetItem('')
                    self.newitem4.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 3, self.newitem4)
#~
                if not item.installedVersion == None:
                    self.newitem3 = QtGui.QTableWidgetItem(item.installedVersion)
                    self.newitem3.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 2, self.newitem3)
                else:
                    self.newitem3 = QtGui.QTableWidgetItem('')
                    self.newitem3.setFlags(QtCore.Qt.ItemIsEnabled)
                    self.table.setItem(self.n, 2, self.newitem3)
                self.n +=1
            
            self.table.setSortingEnabled(True)
        
        self.setCursor(savedCursor)

    def find(self, cad):
        self.name =[]
        for item in self.ls:
            if item.name.startswith(cad):
                self.name.append(item)
        return self.name

    def allPackages(self):
        c =apt_pkg.Cache()
        c.update
        self.lista =[]
        ls =c.packages
        if not len(ls) == 0:
            for name in ls:
                try:
                    pk = self.cache[name.name]
                    self.lista.append(pk)
                except:
                    pass
            return self.lista
        else:
            reply = QtGui.QMessageBox.information(self, "Information", self.MESSAGE)
            if reply == QtGui.QMessageBox.Ok:
                self.close
            else:
                self.informationLabel.setText("Escape")

    def delDir(self, dir):
        shutil.rmtree(dir)

    def check_authoriry(self):
        euid = os.geteuid()
        if euid ==0:
            return True
        else:
            if self.sudo_password is None:
                result = ask_sudo_password()
                if result['result']:
                    self.sudo_password = result['password']
                else:
                    self.sudo_password = None
                    return False
        return True

    def install_package(self, strFileName):

        if not strFileName:
            return False

        if self.check_authoriry():

            if os.geteuid() == 0:
                os.spawnlp(os.P_WAIT, "dpkg", "dpkg", "-i", strFileName)
            elif self.sudo_password:
                exec_command_as_sudo(["dpkg", "-i", strFileName], self.sudo_password)
            else:
                return False
        else:
            return False

        return True

    def install(self):
        if not self.check_authoriry():
            QtGui.QMessageBox.information(self, "Information", self.MESSAGE5)
            return False

        dir ='/tmp/p'
        b = 0
        filename =QtGui.QFileDialog.getOpenFileName(self, 'Select the package to install', '/home')
        if filename:
            k =str(filename)
            self.extractall(k, dir)
            f =open(dir +'/release.txt', 'r')
            while True:
                linea =f.readlines()
                n =len(linea)
                self.pdi.setMaximum(n)
                if not linea:
                    break

                for name in linea:
                    ls = name.split("\n")
                    lss = dir +'/' + ls[0]
                    a = apt.debfile.DebPackage(lss)
                    pk = None
                    if self.cache.has_key(a.pkgname):
                        pk =self.cache[a.pkgname]

                    if(pk and pk.isInstalled):

                        self.pdi.show()
                        self.pdi.setLabelText("Checking package " + a.pkgname)
                    else: # No está instalado!!!

                        if a.check():# Hace un chequeo para ver si se puede instalar !!!
                            self.pdi.setLabelText("Installing package " + a.pkgname)
                            self.install_package(lss)
                        else:
                            QtGui.QMessageBox.information(self, "Information", "The package \"%s\" can't be installed"%a.pkgname)
                            return False

                    b +=1
                    self.pdi.setValue(b)
            self.delDir(dir)
            self.pdi.setValue(n)
        self.sudo_password = None

    def download(self):
        self.b =0
        num = 0
        self.dir1 ='/tmp/d'
        aux =0
        list =[]
        for i in range(self.rows):
            if not self.table.item(i, 0).checkState() == 0:
                aux +=1
                list.append(self.table.item(i, 0).text())
                num += self.cantP(str(self.table.item(i, 0).text()),[str(self.table.item(i, 0).text())])
        if aux == 0:
            reply = QtGui.QMessageBox.information(self, "Information", self.MESSAGE1)
            if reply == QtGui.QMessageBox.Ok:
                self.close
        else:
            fd =QtGui.QFileDialog()
            options = QtGui.QFileDialog.DontResolveSymlinks | QtGui.QFileDialog.ShowDirsOnly
            filename = fd.getExistingDirectory(self, self.tr('Select the download directory '), '/home', options)
            if filename:
                savedCursor = self.cursor()
                self.setCursor(Qt.BusyCursor)
                self.dir =str(filename)
                for i in list:
                    if os.path.exists(self.dir1):
                        shutil.rmtree(self.dir1)
                    name = str(i)
                    os.mkdir(self.dir1)
                    self.pd.setMaximum(num*2)
                    self.download_pkg(name)
                    self.get_deps(name,[name])
                    self.escribirRelease(name,[name])
                    self.zipper(self.dir1, self.dir+'/'+name+'.dac')
                    self.delDir(self.dir1)
                self.pd.setValue(num*2)
                self.setCursor(savedCursor)
                reply = QtGui.QMessageBox.information(self, "Information", self.MESSAGE4)
                if reply == QtGui.QMessageBox.Ok:
                    self.close


    def download_pkg(self,name):
        try:
            pk = self.cache[name]
            pk.versions[0].fetch_binary(self.dir1)
        except apt.package.FetchError:
            reply = QtGui.QMessageBox.critical(self, "Critical error", self.MESSAGE3, QtGui.QMessageBox.Abort | QtGui.QMessageBox.Retry)
            if reply == QtGui.QMessageBox.Abort:
                sys.exit()
            elif reply == QtGui.QMessageBox.Retry:
                self.download()
        except:
            pass


    def escribirRelease(self,name,lista):
        pk =self.cache[name]
        file =open(self.dir1+'/'+'release.txt', 'a')
        if not(pk.versions[0].filename == ""):
            lst = pk.versions[0].filename.split("/")
            file.write(lst[len(lst)-1] + '\n')
            try:
                for dep in pk.candidateDependencies:
                    if not (dep.or_dependencies[0].name in lista):
                        lista.insert(0,dep.or_dependencies[0].name)
                        self.escribirRelease(dep.or_dependencies[0].name, lista)
            except:
                pass

    def get_deps(self,name,lista):
        try:
            pk = self.cache[name]
            for dep in pk.candidateDependencies:
                if not (dep.or_dependencies[0].name in lista):
                    self.download_pkg(dep.or_dependencies[0].name)
                    self.b += 1
                    self.pd.setLabelText("Downloading package " + name)
                    self.pd.setValue(self.b)
                    lista.append(dep.or_dependencies[0].name)
                    self.get_deps(dep.or_dependencies[0].name, lista)
        except:
            pass

    def cantP(self, name, lista):
        try:
            pk = self.cache[name]
            for dep in pk.candidateDependencies:
                if not (dep.or_dependencies[0].name in lista):
                    lista.append(dep.or_dependencies[0].name)
                    self.cantP(dep.or_dependencies[0].name, lista)
        except:
            pass
        return len(lista)


    def zipper(self,dir, zip_file):
        zip = zipfile.ZipFile(zip_file,'w',compression=zipfile.ZIP_DEFLATED)
        root_len = len(os.path.abspath(dir))
        for root, dirs, files in os.walk(dir):
            archive_root = os.path.abspath(root)[root_len:]
            for f in files:
                fullpath = os.path.join(root, f)
                archive_name = os.path.join(archive_root, f)
                self.b +=1
                self.pd.setLabelText("Compressing file " + f)
                self.pd.setValue(self.b)
                zip.write(fullpath, archive_name, zipfile.ZIP_DEFLATED)
        zip.close()
        return zip_file

    def extractall(self, zipfilepath, extractiondir):
        zip = zipfile.ZipFile(zipfilepath)
        zip.extractall(path=extractiondir)

class CommonsTab(QtGui.QWidget):
    def __init__(self, fileInfo, parent=None):
        super(CommonsTab, self).__init__(parent)

        c =apt.Cache()
        pk =c[fileInfo]

        txt =QtGui.QTextEdit()
        lbP = QtGui.QLabel("<b>Package: </b>")
        txt.append("<b>" + pk.name + "</b>")
        txt.append("")
        txt.append(pk.summary)
        txt.setMaximumHeight(70)
        txt.setReadOnly(True)

        lbE =QtGui.QLabel("<b>Status: </b>")
        if pk.is_installed:
            lbS =QtGui.QCheckBox("Installed")
            lbS.setCheckState(QtCore.Qt.Checked)
            lbS.setCheckable(True)
            k = QtGui.QLabel(pk.installedVersion)
            d = pk.installedSize
            u = d/(1000)
            c = QtGui.QLabel(str(u) + " kB")
        else:
            lbS =QtGui.QCheckBox("Not installed")
            lbS.setCheckState(QtCore.Qt.Unchecked)
            lbS.setCheckable(False)
            k = QtGui.QLabel("N/D")
            c = QtGui.QLabel("N/D")


        lbPr =QtGui.QLabel("<b>Priority: </b>")
        lbPri =QtGui.QLabel(pk.versions[0].priority)
        i = QtGui.QLabel("Version: ")
        j = QtGui.QLabel("Size: ")
        lbI =QtGui.QLabel("<b>Installed version </b>")


        lbSection =QtGui.QLabel("<b>Section: </b>")
        lbSection1 =QtGui.QLabel(pk.versions[0].section)

        mainLayout = QtGui.QVBoxLayout()

        self.gridGroupBox = QtGui.QGroupBox()
        layout = QtGui.QFormLayout()
        layout.setSpacing(20)
        layout.addRow(lbP,txt)
        layout.addRow(lbE, lbS)
        layout.addRow(lbPr,lbPri)
        layout.addRow(lbSection, lbSection1)
        layout.addRow(lbI)
        layout.addRow(i,k)
        layout.addRow(j,c)

        self.gridGroupBox.setLayout(layout)


        mainLayout.addWidget(self.gridGroupBox)
        self.setLayout(mainLayout)

class DependsTab(QtGui.QWidget):

    def __init__(self, fileInfo, parent=None):
        super(DependsTab, self).__init__(parent)

        c =apt.Cache()
        pk =c[fileInfo]
        c = pk.candidateDependencies
        l = pk.versions[0].recommends
        con =pk.candidateRecord

        txt =QtGui.QTextEdit()
        txt.setReadOnly(True)

        depends =con.get('Depends')
        suggest =con.get('Suggests')
        recomme =con.get('Recommends')
        conflic =con.get('Conflicts')

        try:
            txt.append("<b>Depends: </b>" + depends)
        except:
            pass
        try:
            txt.append("<b>Suggests: </b>" + suggest)
        except:
            pass
        try:
            txt.append("<b>Recommends: </b>" + recomme)
        except:
            pass
        try:
            txt.append("<b>Conflicts with: </b>" + conflic)
        except:
            pass

        mainLayout = QtGui.QVBoxLayout()
        mainLayout.addWidget(txt)
        self.setLayout(mainLayout)

class VersionsTab(QtGui.QWidget):
    def __init__(self, fileInfo, parent=None):
        super(VersionsTab, self).__init__(parent)

        c =apt.Cache()
        pk =c[fileInfo]

        txt =QtGui.QTextEdit()
        lb = QtGui.QLabel("Avaliable versions: ")
        txt.setText(pk.versions[0].version + '(' + pk.versions[0].source_version + ')')
        txt.setReadOnly(True)
        mainLayout = QtGui.QVBoxLayout()
        mainLayout.addWidget(lb)
        mainLayout.addWidget(txt)
        self.setLayout(mainLayout)

class DescriptionTab(QtGui.QWidget):
    def __init__(self, fileInfo, parent=None):
        super(DescriptionTab, self).__init__(parent)

        c =apt.Cache()
        pk =c[fileInfo]

        txt =QtGui.QTextEdit()
        lb = QtGui.QLabel("<b>Description: </b>")
        txt.setText(pk.description)
        txt.setReadOnly(True)

        mainLayout = QtGui.QVBoxLayout()
        mainLayout.addWidget(lb)
        mainLayout.addWidget(txt)
        self.setLayout(mainLayout)

###*********************
### AGREGADOS POR EBB!!!
###*********************
MSG_GET_SUDO_PASSWD = "Password"

def forknotty(delegate=None):
    """
    Fork the process, detach the child from the terminal, and then wait for it
    to complete in the parent process.

    By using this as the "preexec_fn" parameter for subprocess.MyPopen, one can
    run a sub-process without a terminal. If a parameter is passed to this,
    then it is expected to be another callable object which will be invoked.
    """

    # Fork.
    pid = os.fork()
    if pid > 0:
        for fd in range(subprocess.MAXFD):
            try:
                os.close(fd)
            except OSError: pass
        (pid, return_code) = os.waitpid(pid, 0)
        os._exit(return_code)

    # Detach from parent process.
    os.setsid()
    os.umask(0)

    # Fork again - some UNIXes need this.
    pid = os.fork()
    if pid > 0:
        for fd in range(subprocess.MAXFD):
            try:
                os.close(fd)
            except OSError: pass
        (pid, return_code) = os.waitpid(pid, 0)
        os._exit(return_code)

    # Call the delegate, if any.
    if delegate:
        delegate()

class _MyPopen(subprocess.Popen):
    """
    Wrapper for subprocess.MyPopen, which removes the temporary SSH_ASKPASS
    program.
    """

    def __init__(self, askpass, *args, **kwargs):
        subprocess.Popen.__init__(self, *args, **kwargs)
        self.__askpass = askpass
#    def __del__(self):
#        if os.path.exists(self.__askpass):
#            os.remove(self.__askpass)
#        subprocess.Popen.__del__(self)
    def wait(self):
        try:
            return subprocess.Popen.wait(self)
        finally:
            if os.path.exists(self.__askpass):
                os.remove(self.__askpass)

def MyPopen(command, password, **kwargs):
    """
    Execute the specified command in a subprocess, with SSH_ASKPASS set in such
    a way as to allow passing a password non-interactively to programs that
    need it (e.g. ssh, scp).
    """

    # Set up the "preexec" function, which is forknotty and whatever the user
    # passes in.
    preexec_fn = forknotty
    if "preexec_fn" in kwargs:
        fn = kwargs["preexec_fn"]
        preexec_fn = lambda: forknotty(fn)
    kwargs["preexec_fn"] = preexec_fn

    # Create a temporary, executable-by-owner file.
    (fd, path) = tempfile.mkstemp(text=True)
    os.chmod(path, 0700)

    try:
        tf = os.fdopen(fd, "w")
        print >> tf, "#!" + sys.executable
        print >> tf, "import os; print os.environ['SUDO_PASSWORD']"
        tf.close()

        # Configure environment variables.
        environ = kwargs.get("env", os.environ)
        if environ is None:
            environ = os.environ
        environ = environ.copy()
#
        kwargs["env"] = environ

        environ["SUDO_ASKPASS"] = path
        environ["SUDO_PASSWORD"] = password

        environ["DISPLAY"] = "none:0.0"
        kwargs["env"] = environ

        # Finally, call subprocess.MyPopen.
        return _MyPopen(path, command, **kwargs)
    except:
        import traceback
        traceback.print_exc()
        if os.path.exists(path):
            os.remove(path)

def exec_command_as_sudo(listCommandParameters, password):

    if listCommandParameters:

        command_as_sudo = ["sudo"] + listCommandParameters
        new_env = os.environ.copy()
        proc = MyPopen(command_as_sudo,
                     password,
                     stdin=subprocess.PIPE,
                     stdout=subprocess.PIPE,
                     env=new_env)
        stdout = proc.communicate()[0]
        print stdout
        proc.wait()

def ask_sudo_password(commandToShow="dpkg"):
    result = {'result':False, 'password':None}
    try:
        while(True):
            ctx = gksu.Context()
            ctx.set_command(commandToShow)
            passwd = gksu.ask_password_full(ctx, MSG_GET_SUDO_PASSWD)

            new_env = os.environ.copy()
            proc = MyPopen(["sudo","fdisk", "-l"],
                     passwd,
                     stdin=subprocess.PIPE,
                     stdout=subprocess.PIPE,
                     env=new_env)
            stdout = proc.communicate()[0]
            if stdout:
                result['result'] = True
                result['password'] = passwd
                break
    except gobject.GError, error:
        print error
    return result
###**************

def main():
    app = QtGui.QApplication(sys.argv)
    
    vanta = Dialog()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
